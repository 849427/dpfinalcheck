
public class Main {

	public static void main(String[] args) {
		
		IObserver admin1 = new observer1();
		IObserver admin2 = new observer2();
		IObserver admin3 = new observer3();
		
		NotificationService service = new NotificationService();
		
		service.attach(admin1);
		service.attach(admin2);
		
		service.notifyUpdate(new Ticket(110));
		
		service.detach(admin1);
		
		service.attach(admin3);
		
		service.notifyUpdate(new Ticket(150));
		
		service.setTicket(new Ticket(50));
	}

}
