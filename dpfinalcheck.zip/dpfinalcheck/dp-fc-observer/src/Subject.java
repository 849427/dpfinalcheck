
public interface Subject {

	public void attach(IObserver o);

	public void detach(IObserver o);

	public void notifyUpdate(Ticket ticket);
}
