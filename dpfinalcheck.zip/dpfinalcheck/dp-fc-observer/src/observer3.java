
public class observer3 implements IObserver {

	@Override
	public void update(Ticket ticket) {
		System.out.println("Admin three notified with "+ticket.getTicket()+" tickets");

	}

}
