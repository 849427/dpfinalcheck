
public class observer1 implements IObserver {

	@Override
	public void update(Ticket ticket) {

		System.out.println("Admin one notified with "+ticket.getTicket()+" tickets");
	}

}
