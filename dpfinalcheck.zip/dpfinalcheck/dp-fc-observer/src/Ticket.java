
public class Ticket {

	final int ticket;
	
	public Ticket(int ticket){
		this.ticket = ticket;
	}
	
	public int getTicket(){
		return ticket;
	}
}
