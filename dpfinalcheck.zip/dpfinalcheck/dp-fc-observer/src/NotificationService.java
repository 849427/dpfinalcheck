import java.util.ArrayList;
import java.util.List;

public class NotificationService implements Subject {

	private List<IObserver> admins = new ArrayList<>();
	private Ticket ticket;


	public Ticket getTicket() {
	   return ticket;
	}

	public void setTicket(Ticket ticket) {
	   this.ticket = ticket;
	   notifyAllAdmins();

	}

		 public void notifyAllAdmins(){
		      for (IObserver admin : admins) {
		    	  if(ticket.getTicket()>100){
		         admin.update(ticket);
		    	  }
		    	  else{
		    		  System.out.println("tickets are not enough to notify admins");
		    		  break;
		    	  }
		      }
		   }	


	@Override
	public void attach(IObserver admin) {
	admins.add(admin);
	}

	@Override
	public void detach(IObserver admin) { 
		admins.remove(admin); 
		} 

	@Override 
	public void notifyUpdate(Ticket ticket) { 
		for(IObserver admin: admins) { 
			admin.update(ticket); 
			} 
		} 
}
