
public class observer2 implements IObserver{

	@Override
	public void update(Ticket ticket) {
		System.out.println("Admin two notified with "+ticket.getTicket()+" tickets");
		
	}
	
	

}
