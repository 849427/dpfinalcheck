
public interface IObserver {

	public void update(Ticket ticket);
}
