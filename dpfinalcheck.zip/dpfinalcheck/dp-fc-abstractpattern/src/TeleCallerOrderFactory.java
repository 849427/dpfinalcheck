
public class TeleCallerOrderFactory {

	
	public static Order buildOrder(ProductType productType){
		Order order =null;
		switch(productType){
		
		case ELECTRONIC:
			order = new ElectronicOrder(Channel.TELE_CALLER);
			break;
		
		case TOY:
			order = new ToysOrder(Channel.TELE_CALLER);
			break;
			
		case FURNITURE:
			order = new FurnitureOrder(Channel.TELE_CALLER);
			break;
		
		default:
			break;
		}
		return order;
	}
}
