
public abstract class Order {
		
	Channel channel;
	ProductType productType;
	
	public Order(Channel channel, ProductType productType) {
		super();
		this.channel = channel;
		this.productType = productType;
	}
	
	public abstract void processOrder();
}
