
public class ECommerceOrderFactory{
	
	public static Order buildOrder(ProductType productType){
		Order order =null;
		switch(productType){
		
		case ELECTRONIC:
			order = new ElectronicOrder(Channel.E_COMMERCE);
			break;
		
		case TOY:
			order = new ToysOrder(Channel.E_COMMERCE);
			break;
			
		case FURNITURE:
			order = new FurnitureOrder(Channel.E_COMMERCE);
			break;
		
		default:
			break;
		}
		return order;
	}
}
