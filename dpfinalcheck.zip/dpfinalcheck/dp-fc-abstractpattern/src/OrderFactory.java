
public class OrderFactory {
	
	private OrderFactory(){
		
	}
	
	public static Order buildOrder(Channel channel,ProductType productType){
		
		Order order = null;
		
		switch(channel){
		
		case E_COMMERCE:
			order = ECommerceOrderFactory.buildOrder(productType);
			break;
			
		case TELE_CALLER:
			order = TeleCallerOrderFactory.buildOrder(productType);
			break;
			
		default:
			break;
		}
		
		return order;
	}
}
