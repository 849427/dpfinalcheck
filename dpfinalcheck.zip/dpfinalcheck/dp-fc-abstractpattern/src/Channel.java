

public enum Channel {
	
	E_COMMERCE , TELE_CALLER
}
