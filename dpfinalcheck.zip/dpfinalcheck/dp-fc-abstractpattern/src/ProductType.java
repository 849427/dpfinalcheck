
public enum ProductType {

	ELECTRONIC , TOY , FURNITURE
}
