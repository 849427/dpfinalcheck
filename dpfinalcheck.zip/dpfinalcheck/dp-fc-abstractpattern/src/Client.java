
public class Client {

	public static void main(String[] args) {

		System.out.println(OrderFactory.buildOrder(Channel.E_COMMERCE, ProductType.ELECTRONIC));
		System.out.println(OrderFactory.buildOrder(Channel.TELE_CALLER, ProductType.TOY));
	}

}
