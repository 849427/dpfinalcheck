
public class ElectronicOrder extends Order {

	public ElectronicOrder(Channel channel) {
		super(channel,ProductType.ELECTRONIC);
		processOrder();
	}

	@Override
	public void processOrder() {
		System.out.println("Electronic Order is processing");
	}

}
