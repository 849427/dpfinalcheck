
public class ToysOrder extends Order {

	public ToysOrder(Channel channel) {
		super(channel,ProductType.TOY);
		processOrder();
	}

	@Override
	public void processOrder() {
		System.out.println("Toys order is processing");
	}

}
